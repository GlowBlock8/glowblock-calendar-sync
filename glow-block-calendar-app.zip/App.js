import { registerRootComponent } from 'expo';
import GlowBlockCalendar from './GlowBlockCalendar';
registerRootComponent(GlowBlockCalendar);
