import React, { useEffect, useState } from 'react';
import { View, Text, Button, Alert, ScrollView } from 'react-native';

const requestPermissions = async () => {
  return new Promise((resolve) => setTimeout(() => resolve('authorized'), 500));
};

const saveEvent = async (title, options) => {
  console.log('Simulated saveEvent:', title, options);
  return `simulated-event-${Date.now()}`;
};

const fetchAllEvents = async (startDate, endDate) => {
  console.log(`Simulated fetchAllEvents from ${startDate} to ${endDate}`);
  return [
    { title: 'Simulated Event A', id: 'evt1' },
    { title: 'Simulated Event B', id: 'evt2' },
  ];
};

const CalendarSync = () => {
  const [permissionStatus, setPermissionStatus] = useState('');
  const [events, setEvents] = useState([]);

  useEffect(() => {
    requestCalendarAccess();
  }, []);

  const requestCalendarAccess = async () => {
    try {
      const status = await requestPermissions();
      setPermissionStatus(status);
      console.log('Permission granted:', status);
    } catch (err) {
      console.error('Permission request failed:', err);
    }
  };

  const handleAddEvent = async () => {
    try {
      const id = await saveEvent('Glow Block Session', {
        startDate: '2025-04-17T10:00:00.000Z',
        endDate: '2025-04-17T11:00:00.000Z',
        location: 'Glow HQ Virtual',
        notes: 'Elite focus block ✨',
      });
      Alert.alert('Event Added', `Simulated ID: ${id}`);
    } catch (err) {
      console.error('Add event failed:', err);
    }
  };

  const handleFetchEvents = async () => {
    try {
      const upcoming = await fetchAllEvents('2025-04-17T00:00:00.000Z', '2025-04-18T00:00:00.000Z');
      setEvents(upcoming);
    } catch (err) {
      console.error('Fetch events failed:', err);
    }
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      <Text style={{ fontSize: 22, fontWeight: '600', marginBottom: 15 }}>Glow Block Calendar Sync</Text>
      <Text>Status: {permissionStatus}</Text>

      <View style={{ marginVertical: 10 }}>
        <Button title="Add Glow Event" onPress={handleAddEvent} />
      </View>

      <View style={{ marginVertical: 10 }}>
        <Button title="Fetch Events" onPress={handleFetchEvents} />
      </View>

      {events.length > 0 && (
        <View style={{ marginTop: 20 }}>
          <Text style={{ fontWeight: 'bold' }}>Fetched Events:</Text>
          {events.map((evt, idx) => (
            <Text key={idx} style={{ marginTop: 10 }}>{evt.title}</Text>
          ))}
        </View>
      )}
    </ScrollView>
  );
};

export default CalendarSync;
