import React from 'react';
import CalendarSync from './CalendarSync';

export default function App() {
  return <CalendarSync />;
}
